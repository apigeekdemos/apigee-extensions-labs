
context.setVariable("target.url", context.getVariable("target.url") + ".json"); 