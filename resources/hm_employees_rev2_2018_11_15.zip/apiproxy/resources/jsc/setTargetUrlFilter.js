var employeeId = context.getVariable("employeeId");
var targetUrl = context.getVariable("target.url");
targetUrl += '?orderBy="id"&equalTo="' + employeeId + '"';

context.setVariable("target.url", targetUrl);  