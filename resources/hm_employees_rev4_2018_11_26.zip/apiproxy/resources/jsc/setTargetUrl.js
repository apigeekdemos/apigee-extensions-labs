
context.setVariable("target.url", context.getVariable("target.url") + 
    context.getVariable("proxy.pathsuffix") + ".json"); 