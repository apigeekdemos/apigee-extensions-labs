context.setVariable("target.url", context.getVariable("target.url") + "/" +
    context.getVariable("emp.id") + ".json"); 